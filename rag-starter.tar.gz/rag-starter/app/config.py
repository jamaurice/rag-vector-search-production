"""Configuration loaded from environment variables."""
from __future__ import annotations

from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "postgresql://rag:rag@localhost:5432/rag"

    embedding_provider: Literal["openai", "local"] = "local"
    embedding_dim: int = 384

    openai_api_key: str = ""
    openai_embedding_model: str = "text-embedding-3-small"
    llm_model: str = "gpt-4o-mini"

    local_embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"

    chunk_size_tokens: int = Field(default=400, ge=50, le=4000)
    chunk_overlap_tokens: int = Field(default=80, ge=0, le=1000)

    retrieval_top_k: int = Field(default=10, ge=1, le=100)
    rag_similarity_threshold: float = Field(default=0.5, ge=0.0, le=1.0)


# Singleton accessor. We don't instantiate at import time so tests can override env.
_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


def reset_settings_for_test() -> None:
    """Test hook: drop the cached settings so the next get_settings() re-reads env."""
    global _settings
    _settings = None
