"""Retrieval-Augmented Generation core.

Two retrieval modes:
- vector: pure cosine-similarity search via the HNSW index
- hybrid: combines vector similarity with Postgres full-text rank

Generation uses OpenAI chat completions with the retrieved chunks as context.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from app.config import get_settings
from app.db import get_conn
from app.embeddings import get_embedder
from app.schemas import SearchHit


@dataclass
class RetrievedChunk:
    chunk_id: int
    document_id: int
    source: str
    title: str | None
    content: str
    similarity: float
    metadata: dict[str, Any]

    def to_hit(self) -> SearchHit:
        return SearchHit(
            chunk_id=self.chunk_id,
            document_id=self.document_id,
            source=self.source,
            title=self.title,
            content=self.content,
            similarity=self.similarity,
            metadata=self.metadata,
        )


# --- Retrieval --------------------------------------------------------------


def _build_metadata_filter(where: dict[str, Any]) -> tuple[str, list[Any]]:
    """Translate a flat dict into a SQL WHERE fragment over documents.metadata / source.

    Supports keys: 'source' (matches documents.source), anything else is treated as a
    JSONB equality check on documents.metadata.
    Returns (sql_fragment, params). sql_fragment is empty if where is empty.
    """
    if not where:
        return "", []
    clauses: list[str] = []
    params: list[Any] = []
    for key, value in where.items():
        if key == "source":
            clauses.append("d.source = %s")
            params.append(value)
        else:
            # JSONB containment: metadata @> '{"key": value}'
            clauses.append("d.metadata @> %s::jsonb")
            params.append(json.dumps({key: value}))
    return " AND " + " AND ".join(clauses), params


def vector_search(
    query: str,
    top_k: int,
    where: dict[str, Any] | None = None,
) -> list[RetrievedChunk]:
    """Pure vector similarity search."""
    embedder = get_embedder()
    qv = embedder.embed_one(query)

    filter_sql, filter_params = _build_metadata_filter(where or {})
    sql = f"""
        SELECT
            c.id,
            c.document_id,
            d.source,
            d.title,
            c.content,
            1 - (c.embedding <=> %s::vector) AS similarity,
            d.metadata
        FROM chunks c
        JOIN documents d ON d.id = c.document_id
        WHERE TRUE {filter_sql}
        ORDER BY c.embedding <=> %s::vector
        LIMIT %s
    """
    params = [qv, *filter_params, qv, top_k]

    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params)
        rows = cur.fetchall()

    return [
        RetrievedChunk(
            chunk_id=r[0],
            document_id=r[1],
            source=r[2],
            title=r[3],
            content=r[4],
            similarity=float(r[5]),
            metadata=r[6] or {},
        )
        for r in rows
    ]


def hybrid_search(
    query: str,
    top_k: int,
    where: dict[str, Any] | None = None,
    vector_weight: float = 0.7,
) -> list[RetrievedChunk]:
    """Combine vector similarity and Postgres full-text rank.

    Pulls the top 50 from each, normalizes the scores, and blends with a fixed weight.
    For real workloads you'll want to tune vector_weight and the candidate pool size.
    """
    if not 0.0 <= vector_weight <= 1.0:
        raise ValueError("vector_weight must be in [0, 1]")
    keyword_weight = 1.0 - vector_weight

    embedder = get_embedder()
    qv = embedder.embed_one(query)
    filter_sql, filter_params = _build_metadata_filter(where or {})

    sql = f"""
        WITH vec AS (
            SELECT c.id, 1 - (c.embedding <=> %s::vector) AS sim
            FROM chunks c
            JOIN documents d ON d.id = c.document_id
            WHERE TRUE {filter_sql}
            ORDER BY c.embedding <=> %s::vector
            LIMIT 50
        ),
        kw AS (
            SELECT c.id,
                   ts_rank(c.content_tsv, plainto_tsquery('english', %s)) AS rank
            FROM chunks c
            JOIN documents d ON d.id = c.document_id
            WHERE c.content_tsv @@ plainto_tsquery('english', %s) {filter_sql}
            ORDER BY rank DESC
            LIMIT 50
        ),
        combined AS (
            SELECT id FROM vec
            UNION
            SELECT id FROM kw
        ),
        scored AS (
            SELECT
                combined.id,
                COALESCE(vec.sim, 0) AS vec_score,
                COALESCE(kw.rank, 0) AS kw_score
            FROM combined
            LEFT JOIN vec ON vec.id = combined.id
            LEFT JOIN kw ON kw.id = combined.id
        ),
        normalized AS (
            -- min-max normalize within this result set so the two scores are comparable
            SELECT
                id,
                CASE WHEN MAX(vec_score) OVER () = MIN(vec_score) OVER ()
                     THEN 0
                     ELSE (vec_score - MIN(vec_score) OVER ())
                          / NULLIF(MAX(vec_score) OVER () - MIN(vec_score) OVER (), 0)
                END AS vec_norm,
                CASE WHEN MAX(kw_score) OVER () = MIN(kw_score) OVER ()
                     THEN 0
                     ELSE (kw_score - MIN(kw_score) OVER ())
                          / NULLIF(MAX(kw_score) OVER () - MIN(kw_score) OVER (), 0)
                END AS kw_norm
            FROM scored
        )
        SELECT
            c.id,
            c.document_id,
            d.source,
            d.title,
            c.content,
            (%s * n.vec_norm + %s * n.kw_norm) AS final_score,
            d.metadata
        FROM normalized n
        JOIN chunks c ON c.id = n.id
        JOIN documents d ON d.id = c.document_id
        ORDER BY final_score DESC
        LIMIT %s
    """
    # We pass filter_params three times because filter_sql is interpolated three times.
    params = [
        qv, *filter_params,           # vec CTE filter
        qv,                            # vec CTE order by
        query,                         # kw CTE rank
        query, *filter_params,         # kw CTE where + filter
        vector_weight, keyword_weight,
        top_k,
    ]

    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params)
        rows = cur.fetchall()

    return [
        RetrievedChunk(
            chunk_id=r[0],
            document_id=r[1],
            source=r[2],
            title=r[3],
            content=r[4],
            similarity=float(r[5]),
            metadata=r[6] or {},
        )
        for r in rows
    ]


def retrieve(
    query: str,
    top_k: int,
    mode: str = "vector",
    where: dict[str, Any] | None = None,
) -> list[RetrievedChunk]:
    if mode == "hybrid":
        return hybrid_search(query, top_k, where)
    return vector_search(query, top_k, where)


# --- Generation -------------------------------------------------------------


_SYSTEM_PROMPT = (
    "You answer questions strictly from the provided context. "
    "If the context does not contain the answer, say so plainly. "
    "Cite sources by their numbered tag, e.g. [1], [2]. "
    "Do not invent facts."
)


def _build_context(chunks: list[RetrievedChunk]) -> str:
    parts: list[str] = []
    for i, c in enumerate(chunks, start=1):
        title = c.title or c.source
        parts.append(f"[{i}] {title} (similarity={c.similarity:.3f})\n{c.content}")
    return "\n\n---\n\n".join(parts)


def generate_answer(question: str, chunks: list[RetrievedChunk]) -> tuple[str, str]:
    """Call the LLM with retrieved context. Returns (answer, model_used).

    Requires OPENAI_API_KEY regardless of which embedding provider you're using.
    If you want a local-only setup, swap this for an Ollama / llama.cpp call.
    """
    from openai import OpenAI

    settings = get_settings()
    if not settings.openai_api_key:
        raise RuntimeError(
            "OPENAI_API_KEY is required for /ask. Set it or call /search instead."
        )

    if not chunks:
        return ("I don't have any relevant documents to answer that.", settings.llm_model)

    context = _build_context(chunks)
    user_prompt = f"Context:\n{context}\n\nQuestion: {question}\n\nAnswer:"

    client = OpenAI(api_key=settings.openai_api_key)
    resp = client.chat.completions.create(
        model=settings.llm_model,
        messages=[
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.1,
    )
    return resp.choices[0].message.content or "", settings.llm_model
