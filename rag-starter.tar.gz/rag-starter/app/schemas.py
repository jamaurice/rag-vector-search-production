"""Pydantic models for the API."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


# --- Ingest -----------------------------------------------------------------


class IngestRequest(BaseModel):
    source: str = Field(..., description="Origin identifier (filename, URL, etc.)")
    title: str | None = None
    content: str = Field(..., min_length=1)
    metadata: dict[str, Any] = Field(default_factory=dict)


class IngestResponse(BaseModel):
    document_id: int
    chunks_created: int


# --- Search -----------------------------------------------------------------


class SearchRequest(BaseModel):
    query: str = Field(..., min_length=1)
    top_k: int = Field(default=10, ge=1, le=50)
    mode: str = Field(default="vector", pattern="^(vector|hybrid)$")
    # Optional metadata filter, e.g. {"source": "handbook.md"}
    where: dict[str, Any] = Field(default_factory=dict)


class SearchHit(BaseModel):
    chunk_id: int
    document_id: int
    source: str
    title: str | None
    content: str
    similarity: float
    metadata: dict[str, Any]


class SearchResponse(BaseModel):
    hits: list[SearchHit]


# --- Ask (RAG) --------------------------------------------------------------


class AskRequest(BaseModel):
    question: str = Field(..., min_length=1)
    top_k: int = Field(default=5, ge=1, le=20)
    mode: str = Field(default="vector", pattern="^(vector|hybrid)$")


class AskResponse(BaseModel):
    answer: str
    sources: list[SearchHit]
    model: str
