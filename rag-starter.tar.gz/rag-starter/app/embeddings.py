"""Provider-agnostic embedding interface.

Two implementations:
- OpenAIEmbedder: calls the OpenAI embeddings API.
- LocalEmbedder: runs sentence-transformers in-process.

Pick via the EMBEDDING_PROVIDER env var. The dimension must match EMBEDDING_DIM,
which is also baked into the SQL schema. Switching providers in place is not
supported -- you'd be mixing vectors from different latent spaces in the same
table, and similarity comparisons across them are meaningless.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from functools import lru_cache
from typing import Sequence

from app.config import get_settings


class Embedder(ABC):
    """Common interface."""

    model_name: str
    dim: int

    @abstractmethod
    def embed(self, texts: Sequence[str]) -> list[list[float]]:
        """Embed a batch of texts. Always returns a list of vectors of length len(texts)."""

    def embed_one(self, text: str) -> list[float]:
        return self.embed([text])[0]


class OpenAIEmbedder(Embedder):
    def __init__(self, model_name: str, dim: int, api_key: str) -> None:
        if not api_key:
            raise ValueError(
                "OPENAI_API_KEY is empty but EMBEDDING_PROVIDER=openai. "
                "Set the key or switch to provider=local."
            )
        # Imported lazily so callers without the openai package can still import
        # this module (e.g. tests that only use the local provider).
        from openai import OpenAI

        self._client = OpenAI(api_key=api_key)
        self.model_name = model_name
        self.dim = dim

    def embed(self, texts: Sequence[str]) -> list[list[float]]:
        if not texts:
            return []
        resp = self._client.embeddings.create(model=self.model_name, input=list(texts))
        vectors = [d.embedding for d in resp.data]
        # Sanity check: the configured dim must match what the API returned.
        if vectors and len(vectors[0]) != self.dim:
            raise RuntimeError(
                f"OpenAI returned {len(vectors[0])}-dim vectors but EMBEDDING_DIM={self.dim}. "
                "Update EMBEDDING_DIM and rebuild the schema."
            )
        return vectors


class LocalEmbedder(Embedder):
    def __init__(self, model_name: str, dim: int) -> None:
        from sentence_transformers import SentenceTransformer

        self._model = SentenceTransformer(model_name)
        self.model_name = model_name
        self.dim = dim
        actual = self._model.get_sentence_embedding_dimension()
        if actual != dim:
            raise RuntimeError(
                f"Local model {model_name} produces {actual}-dim vectors but "
                f"EMBEDDING_DIM={dim}. Update EMBEDDING_DIM and rebuild the schema."
            )

    def embed(self, texts: Sequence[str]) -> list[list[float]]:
        if not texts:
            return []
        # convert_to_numpy=False keeps it as a list of tensors; tolist() gives plain lists.
        out = self._model.encode(list(texts), convert_to_numpy=True, show_progress_bar=False)
        return out.tolist()


@lru_cache(maxsize=1)
def get_embedder() -> Embedder:
    """Build the embedder once per process."""
    s = get_settings()
    if s.embedding_provider == "openai":
        return OpenAIEmbedder(
            model_name=s.openai_embedding_model,
            dim=s.embedding_dim,
            api_key=s.openai_api_key,
        )
    if s.embedding_provider == "local":
        return LocalEmbedder(model_name=s.local_embedding_model, dim=s.embedding_dim)
    raise ValueError(f"Unknown EMBEDDING_PROVIDER: {s.embedding_provider}")


def reset_embedder_for_test() -> None:
    get_embedder.cache_clear()
