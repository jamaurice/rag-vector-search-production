"""Token-aware text chunking.

Uses tiktoken to count tokens accurately rather than guessing by word count.
Chunks overlap so that information spanning a chunk boundary isn't lost.

This is intentionally simple. For real document workloads you may want:
- Structure-aware chunking (headings, sections)
- Sentence-boundary preservation
- Recursive chunking by separator hierarchy

Those are reasonable extensions; for a starter, fixed-size token windows are fine.
"""
from __future__ import annotations

from dataclasses import dataclass

import tiktoken

# cl100k_base is the tokenizer for OpenAI's text-embedding-3-* and gpt-4o models.
# It's also a fine general-purpose token counter for non-OpenAI use.
_ENCODER = tiktoken.get_encoding("cl100k_base")


@dataclass(frozen=True)
class Chunk:
    index: int
    text: str
    token_count: int


def chunk_text(
    text: str,
    chunk_size_tokens: int = 400,
    overlap_tokens: int = 80,
) -> list[Chunk]:
    """Split text into overlapping token windows.

    Args:
        text: Source text. Whitespace is preserved within chunks.
        chunk_size_tokens: Target tokens per chunk.
        overlap_tokens: How many tokens of context to repeat between chunks.

    Returns:
        List of Chunk objects in order. Empty list if text is empty/whitespace.
    """
    if chunk_size_tokens <= 0:
        raise ValueError("chunk_size_tokens must be positive")
    if overlap_tokens < 0 or overlap_tokens >= chunk_size_tokens:
        raise ValueError("overlap_tokens must be in [0, chunk_size_tokens)")

    text = text.strip()
    if not text:
        return []

    tokens = _ENCODER.encode(text)
    if not tokens:
        return []

    step = chunk_size_tokens - overlap_tokens
    chunks: list[Chunk] = []
    idx = 0
    start = 0
    while start < len(tokens):
        end = min(start + chunk_size_tokens, len(tokens))
        window = tokens[start:end]
        chunk_text = _ENCODER.decode(window)
        chunks.append(Chunk(index=idx, text=chunk_text, token_count=len(window)))
        idx += 1
        if end == len(tokens):
            break
        start += step
    return chunks
