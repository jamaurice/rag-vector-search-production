"""FastAPI application.

Endpoints:
    GET  /health            liveness check
    POST /ingest            index a single document (chunks + embeds + stores)
    POST /search            retrieve chunks (vector or hybrid)
    POST /ask               retrieve + generate answer
"""
from __future__ import annotations

import json
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException

from app.chunking import chunk_text
from app.config import get_settings
from app.db import close_pool, get_conn
from app.embeddings import get_embedder
from app.rag import generate_answer, retrieve
from app.schemas import (
    AskRequest,
    AskResponse,
    IngestRequest,
    IngestResponse,
    SearchRequest,
    SearchResponse,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Warm the embedder so the first request isn't slow.
    get_embedder()
    yield
    close_pool()


app = FastAPI(title="RAG Starter", version="0.1.0", lifespan=lifespan)


@app.get("/health")
def health() -> dict:
    try:
        with get_conn() as conn, conn.cursor() as cur:
            cur.execute("SELECT 1")
            cur.fetchone()
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=503, detail=f"db unavailable: {exc}") from exc
    return {"status": "ok"}


@app.post("/ingest", response_model=IngestResponse)
def ingest(req: IngestRequest) -> IngestResponse:
    settings = get_settings()
    chunks = chunk_text(
        req.content,
        chunk_size_tokens=settings.chunk_size_tokens,
        overlap_tokens=settings.chunk_overlap_tokens,
    )
    if not chunks:
        raise HTTPException(status_code=400, detail="content produced zero chunks")

    embedder = get_embedder()
    vectors = embedder.embed([c.text for c in chunks])

    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(
            "INSERT INTO documents (source, title, metadata) VALUES (%s, %s, %s::jsonb) RETURNING id",
            (req.source, req.title, json.dumps(req.metadata)),
        )
        row = cur.fetchone()
        assert row is not None
        document_id = row[0]

        # Bulk insert chunks. executemany is fine here; for larger ingests use COPY.
        cur.executemany(
            """
            INSERT INTO chunks (document_id, chunk_index, content, embedding_model, embedding)
            VALUES (%s, %s, %s, %s, %s)
            """,
            [
                (document_id, c.index, c.text, embedder.model_name, v)
                for c, v in zip(chunks, vectors)
            ],
        )

    return IngestResponse(document_id=document_id, chunks_created=len(chunks))


@app.post("/search", response_model=SearchResponse)
def search(req: SearchRequest) -> SearchResponse:
    chunks = retrieve(req.query, top_k=req.top_k, mode=req.mode, where=req.where)
    return SearchResponse(hits=[c.to_hit() for c in chunks])


@app.post("/ask", response_model=AskResponse)
def ask(req: AskRequest) -> AskResponse:
    settings = get_settings()
    chunks = retrieve(req.question, top_k=req.top_k, mode=req.mode)
    # Filter out low-confidence chunks before sending to the LLM.
    chunks = [c for c in chunks if c.similarity >= settings.rag_similarity_threshold]
    answer, model = generate_answer(req.question, chunks)
    return AskResponse(
        answer=answer,
        sources=[c.to_hit() for c in chunks],
        model=model,
    )
