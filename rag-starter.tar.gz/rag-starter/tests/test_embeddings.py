"""Tests for the embedding adapter layer.

We don't hit the real OpenAI API or load a real sentence-transformers model.
Instead we test that the abstract Embedder contract behaves correctly and that
the dimension validation logic catches mismatches.
"""
from __future__ import annotations

import pytest

from app.embeddings import Embedder


class FakeEmbedder(Embedder):
    """Deterministic fake for contract tests."""

    def __init__(self, dim: int = 4):
        self.model_name = "fake"
        self.dim = dim

    def embed(self, texts):
        return [[float(i)] * self.dim for i, _ in enumerate(texts)]


def test_embed_one_returns_single_vector():
    e = FakeEmbedder(dim=4)
    v = e.embed_one("hello")
    assert len(v) == 4


def test_embed_empty_input_returns_empty():
    e = FakeEmbedder(dim=4)
    assert e.embed([]) == []


def test_embed_preserves_order():
    e = FakeEmbedder(dim=2)
    out = e.embed(["a", "b", "c"])
    assert len(out) == 3
    # Our fake encodes the index into the values, so order is verifiable.
    assert out[0] == [0.0, 0.0]
    assert out[1] == [1.0, 1.0]
    assert out[2] == [2.0, 2.0]


def test_openai_embedder_rejects_empty_api_key():
    from app.embeddings import OpenAIEmbedder

    with pytest.raises(ValueError, match="OPENAI_API_KEY"):
        OpenAIEmbedder(model_name="text-embedding-3-small", dim=1536, api_key="")
