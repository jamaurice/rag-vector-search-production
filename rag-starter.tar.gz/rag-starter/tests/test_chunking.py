"""Tests for the token-aware chunker."""
from __future__ import annotations

import pytest

from app.chunking import chunk_text


def test_empty_input_returns_empty_list():
    assert chunk_text("") == []
    assert chunk_text("   \n\n  ") == []


def test_short_text_produces_single_chunk():
    chunks = chunk_text("Hello, world.", chunk_size_tokens=400, overlap_tokens=80)
    assert len(chunks) == 1
    assert chunks[0].index == 0
    assert "Hello" in chunks[0].text


def test_long_text_produces_multiple_chunks():
    # Build a text long enough to exceed several chunks.
    text = " ".join(["lorem ipsum dolor sit amet"] * 500)
    chunks = chunk_text(text, chunk_size_tokens=100, overlap_tokens=20)
    assert len(chunks) > 1
    # Indexes are monotonically increasing from 0.
    assert [c.index for c in chunks] == list(range(len(chunks)))


def test_overlap_creates_shared_content_between_adjacent_chunks():
    # Distinct numbered tokens make overlap easy to spot.
    text = " ".join(f"word{i}" for i in range(500))
    chunks = chunk_text(text, chunk_size_tokens=50, overlap_tokens=10)
    assert len(chunks) >= 2
    # The end of chunk[0] and start of chunk[1] should share at least one word.
    a_words = set(chunks[0].text.split())
    b_words = set(chunks[1].text.split())
    assert a_words & b_words, "expected overlap between adjacent chunks"


def test_overlap_must_be_smaller_than_chunk_size():
    with pytest.raises(ValueError):
        chunk_text("hello", chunk_size_tokens=100, overlap_tokens=100)
    with pytest.raises(ValueError):
        chunk_text("hello", chunk_size_tokens=100, overlap_tokens=200)


def test_chunk_size_must_be_positive():
    with pytest.raises(ValueError):
        chunk_text("hello", chunk_size_tokens=0, overlap_tokens=0)
    with pytest.raises(ValueError):
        chunk_text("hello", chunk_size_tokens=-10, overlap_tokens=0)


def test_token_count_reported_matches_chunk():
    text = " ".join(["alpha"] * 200)
    chunks = chunk_text(text, chunk_size_tokens=50, overlap_tokens=10)
    for c in chunks:
        assert c.token_count > 0
        assert c.token_count <= 50
