"""End-to-end API tests against a real Postgres+pgvector container.

These tests:
1. Spin up a pgvector-enabled Postgres in Docker via testcontainers.
2. Apply the schema with a small embedding dim.
3. Monkey-patch the embedder to a deterministic fake so we don't need OpenAI
   or sentence-transformers loaded.
4. Hit the FastAPI app via TestClient.

If Docker isn't available, these tests are skipped.

Run with:  pytest tests/test_api.py -v
"""
from __future__ import annotations

import os
from pathlib import Path

import pytest

# Skip the whole module if docker isn't usable.
docker = pytest.importorskip("docker")
try:
    docker.from_env().ping()
except Exception:  # noqa: BLE001
    pytest.skip("Docker not available", allow_module_level=True)

from testcontainers.postgres import PostgresContainer  # noqa: E402

PGVECTOR_IMAGE = "pgvector/pgvector:pg16"


@pytest.fixture(scope="module")
def pg():
    with PostgresContainer(PGVECTOR_IMAGE, username="rag", password="rag", dbname="rag") as c:
        yield c


@pytest.fixture(scope="module", autouse=True)
def _env(pg, monkeypatch_module):
    url = pg.get_connection_url().replace("postgresql+psycopg2://", "postgresql://")
    monkeypatch_module.setenv("DATABASE_URL", url)
    monkeypatch_module.setenv("EMBEDDING_PROVIDER", "local")  # not actually used; we patch
    monkeypatch_module.setenv("EMBEDDING_DIM", "4")
    monkeypatch_module.setenv("OPENAI_API_KEY", "")  # /ask is not exercised here

    # Reset cached singletons so they pick up the new env.
    from app.config import reset_settings_for_test
    from app.embeddings import reset_embedder_for_test
    from app import db as db_module

    reset_settings_for_test()
    reset_embedder_for_test()
    db_module.close_pool()

    # Apply schema with the small dim baked in.
    schema_sql = Path("sql/schema.sql").read_text().replace("{EMBEDDING_DIM}", "4")
    from app.db import get_conn
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(schema_sql)


@pytest.fixture(scope="module")
def monkeypatch_module():
    # pytest's built-in monkeypatch is function-scoped; we want module scope.
    from _pytest.monkeypatch import MonkeyPatch
    mp = MonkeyPatch()
    yield mp
    mp.undo()


@pytest.fixture
def fake_embedder(monkeypatch):
    """Patch get_embedder to return a deterministic 4-dim fake."""
    class Fake:
        model_name = "fake-test"
        dim = 4

        def embed(self, texts):
            # Encode the first character of each text into the vector so semantically
            # similar texts (same first char) get similar vectors. Crude but enough
            # for retrieval ordering tests.
            out = []
            for t in texts:
                base = ord(t[0].lower()) if t else 0
                out.append([float(base) / 256.0, 0.1, 0.1, 0.1])
            return out

        def embed_one(self, text):
            return self.embed([text])[0]

    fake = Fake()
    # Patch every site that calls get_embedder.
    monkeypatch.setattr("app.embeddings.get_embedder", lambda: fake)
    monkeypatch.setattr("app.main.get_embedder", lambda: fake)
    monkeypatch.setattr("app.rag.get_embedder", lambda: fake)
    return fake


@pytest.fixture
def client(fake_embedder):
    from fastapi.testclient import TestClient
    from app.main import app

    with TestClient(app) as c:
        # Clean tables between tests so order is deterministic.
        from app.db import get_conn
        with get_conn() as conn, conn.cursor() as cur:
            cur.execute("TRUNCATE chunks, documents RESTART IDENTITY CASCADE")
        yield c


def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json() == {"status": "ok"}


def test_ingest_creates_document_and_chunks(client):
    r = client.post(
        "/ingest",
        json={
            "source": "test.md",
            "title": "Test",
            "content": "alpha beta gamma " * 50,  # long enough to chunk
        },
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["document_id"] >= 1
    assert body["chunks_created"] >= 1


def test_ingest_rejects_empty_content(client):
    r = client.post("/ingest", json={"source": "x", "content": "   "})
    # pydantic min_length=1 rejects whitespace-stripped-empty? It rejects pre-strip empty;
    # whitespace-only passes validation but produces zero chunks -> 400.
    assert r.status_code in (400, 422)


def test_search_returns_ingested_content(client):
    client.post("/ingest", json={"source": "a.md", "content": "apple apple apple"})
    client.post("/ingest", json={"source": "b.md", "content": "banana banana banana"})

    r = client.post("/search", json={"query": "apple", "top_k": 5})
    assert r.status_code == 200
    hits = r.json()["hits"]
    assert len(hits) >= 1
    # The fake embedder buckets by first character, so 'a'-prefixed should be most similar.
    assert hits[0]["source"] == "a.md"


def test_search_with_metadata_filter(client):
    client.post("/ingest", json={"source": "keep.md", "content": "alpha"})
    client.post("/ingest", json={"source": "skip.md", "content": "alpha"})

    r = client.post("/search", json={"query": "alpha", "top_k": 5, "where": {"source": "keep.md"}})
    assert r.status_code == 200
    hits = r.json()["hits"]
    assert len(hits) >= 1
    assert all(h["source"] == "keep.md" for h in hits)


def test_hybrid_search_runs(client):
    client.post("/ingest", json={"source": "h.md", "content": "the quick brown fox jumps"})
    r = client.post("/search", json={"query": "fox", "top_k": 5, "mode": "hybrid"})
    assert r.status_code == 200
    assert isinstance(r.json()["hits"], list)
