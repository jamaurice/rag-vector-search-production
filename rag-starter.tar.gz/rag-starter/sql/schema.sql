-- Enable pgvector
CREATE EXTENSION IF NOT EXISTS vector;

-- Documents are the logical unit (a file, a page, an article).
CREATE TABLE IF NOT EXISTS documents (
    id BIGSERIAL PRIMARY KEY,
    source TEXT NOT NULL,            -- where it came from (filename, URL, etc.)
    title TEXT,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Chunks are what we actually embed and search over.
-- One document -> many chunks.
CREATE TABLE IF NOT EXISTS chunks (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    chunk_index INT NOT NULL,
    content TEXT NOT NULL,
    embedding_model TEXT NOT NULL,       -- e.g. "text-embedding-3-small"
    embedding VECTOR({EMBEDDING_DIM}),   -- placeholder; replaced at init time
    -- tsvector for hybrid search; generated column kept in sync automatically
    content_tsv TSVECTOR GENERATED ALWAYS AS (to_tsvector('english', content)) STORED,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (document_id, chunk_index)
);

-- HNSW index on embeddings, cosine distance.
-- m and ef_construction are reasonable defaults; tune for your data.
CREATE INDEX IF NOT EXISTS chunks_embedding_hnsw
    ON chunks
    USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 64);

-- GIN index for full-text fallback / hybrid search.
CREATE INDEX IF NOT EXISTS chunks_tsv_gin ON chunks USING GIN (content_tsv);

-- For filtering by document/source.
CREATE INDEX IF NOT EXISTS chunks_document_id_idx ON chunks(document_id);
CREATE INDEX IF NOT EXISTS documents_source_idx ON documents(source);
