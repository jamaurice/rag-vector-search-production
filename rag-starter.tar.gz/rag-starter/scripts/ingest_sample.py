"""Ingest a handful of sample documents so /search returns something sensible.

Usage:
    python -m scripts.ingest_sample
"""
from __future__ import annotations

import json

from app.chunking import chunk_text
from app.config import get_settings
from app.db import get_conn
from app.embeddings import get_embedder

SAMPLES = [
    {
        "source": "pgvector_intro.md",
        "title": "What is pgvector?",
        "content": (
            "pgvector is a Postgres extension that adds a vector data type and "
            "similarity search operators. It supports L2 distance, inner product, "
            "and cosine distance. Indexes available include IVFFlat and HNSW. "
            "HNSW typically gives better recall at higher memory cost."
        ),
    },
    {
        "source": "rag_overview.md",
        "title": "Retrieval-Augmented Generation",
        "content": (
            "RAG augments a language model with retrieved context from a "
            "knowledge base. The pipeline is: embed the query, search a vector "
            "store for similar chunks, pass those chunks to the LLM as context, "
            "and generate an answer. RAG reduces hallucination because the model "
            "is grounded in real source material it can cite."
        ),
    },
    {
        "source": "chunking_notes.md",
        "title": "Why chunk documents?",
        "content": (
            "Embedding a long document as a single vector loses local detail. "
            "Chunking splits the document into pieces small enough that each "
            "embedding is meaningful. Overlap between chunks keeps context that "
            "spans boundaries from being lost. Chunk size is a tradeoff: smaller "
            "chunks give finer-grained retrieval, larger chunks give more context "
            "to the LLM at generation time."
        ),
    },
    {
        "source": "hybrid_search.md",
        "title": "Hybrid search",
        "content": (
            "Vector search captures semantic similarity but can miss exact-term "
            "matches like product codes or rare names. Combining vector search "
            "with full-text keyword search and blending the scores recovers "
            "those cases. Postgres provides tsvector and ts_rank for the "
            "keyword side, which composes naturally with pgvector."
        ),
    },
]


def main() -> None:
    settings = get_settings()
    embedder = get_embedder()

    with get_conn() as conn, conn.cursor() as cur:
        for sample in SAMPLES:
            chunks = chunk_text(
                sample["content"],
                chunk_size_tokens=settings.chunk_size_tokens,
                overlap_tokens=settings.chunk_overlap_tokens,
            )
            vectors = embedder.embed([c.text for c in chunks])

            cur.execute(
                "INSERT INTO documents (source, title, metadata) "
                "VALUES (%s, %s, %s::jsonb) RETURNING id",
                (sample["source"], sample["title"], json.dumps({})),
            )
            row = cur.fetchone()
            assert row is not None
            doc_id = row[0]

            cur.executemany(
                """
                INSERT INTO chunks (document_id, chunk_index, content, embedding_model, embedding)
                VALUES (%s, %s, %s, %s, %s)
                """,
                [
                    (doc_id, c.index, c.text, embedder.model_name, v)
                    for c, v in zip(chunks, vectors)
                ],
            )
            print(f"Ingested {sample['source']}: {len(chunks)} chunks")


if __name__ == "__main__":
    main()
