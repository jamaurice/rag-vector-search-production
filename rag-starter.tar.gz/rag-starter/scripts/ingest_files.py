"""Ingest every .txt and .md file under a directory.

Usage:
    python -m scripts.ingest_files /path/to/docs

Each file becomes one document; its content is chunked per the configured chunk size.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from app.chunking import chunk_text
from app.config import get_settings
from app.db import get_conn
from app.embeddings import get_embedder

SUPPORTED_SUFFIXES = {".txt", ".md"}


def ingest_path(root: Path) -> int:
    if not root.exists():
        print(f"Path not found: {root}", file=sys.stderr)
        return 1
    if root.is_file():
        files = [root] if root.suffix.lower() in SUPPORTED_SUFFIXES else []
    else:
        files = [p for p in root.rglob("*") if p.suffix.lower() in SUPPORTED_SUFFIXES]
    if not files:
        print(f"No .txt or .md files found under {root}", file=sys.stderr)
        return 1

    settings = get_settings()
    embedder = get_embedder()

    total_chunks = 0
    with get_conn() as conn, conn.cursor() as cur:
        for path in files:
            content = path.read_text(encoding="utf-8", errors="replace")
            chunks = chunk_text(
                content,
                chunk_size_tokens=settings.chunk_size_tokens,
                overlap_tokens=settings.chunk_overlap_tokens,
            )
            if not chunks:
                print(f"Skipping (empty): {path}")
                continue
            vectors = embedder.embed([c.text for c in chunks])

            cur.execute(
                "INSERT INTO documents (source, title, metadata) "
                "VALUES (%s, %s, %s::jsonb) RETURNING id",
                (str(path), path.stem, json.dumps({"path": str(path)})),
            )
            row = cur.fetchone()
            assert row is not None
            doc_id = row[0]

            cur.executemany(
                """
                INSERT INTO chunks (document_id, chunk_index, content, embedding_model, embedding)
                VALUES (%s, %s, %s, %s, %s)
                """,
                [
                    (doc_id, c.index, c.text, embedder.model_name, v)
                    for c, v in zip(chunks, vectors)
                ],
            )
            total_chunks += len(chunks)
            print(f"  {path}: {len(chunks)} chunks")

    print(f"Done. {len(files)} files, {total_chunks} chunks.")
    return 0


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("path", help="File or directory to ingest")
    args = parser.parse_args()
    sys.exit(ingest_path(Path(args.path)))


if __name__ == "__main__":
    main()
