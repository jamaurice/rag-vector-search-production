"""Apply sql/schema.sql, substituting the configured embedding dimension.

Usage:
    python -m scripts.init_db
"""
from __future__ import annotations

from pathlib import Path

from app.config import get_settings
from app.db import get_conn

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "sql" / "schema.sql"


def main() -> None:
    settings = get_settings()
    raw = SCHEMA_PATH.read_text()
    sql = raw.replace("{EMBEDDING_DIM}", str(settings.embedding_dim))

    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql)
    print(f"Schema applied with embedding_dim={settings.embedding_dim}")


if __name__ == "__main__":
    main()
